package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta4Binding

class pergunta4 : Fragment() {


    private var _binding: FragmentPergunta4Binding? = null
    private val binding get() = _binding!!
    val args : pergunta4Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta4Binding.inflate(inflater, container, false)
        binding.back4?.setOnClickListener{
            findNavController().popBackStack()
        }
        val view = binding.root

        binding.btn4.setOnClickListener {
            val direction = pergunta4Directions
            if(binding.R4A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q4A.isChecked) {
                    val action = direction.actionQuartaperguntaToQuintapergunta(args.pontos)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q4B.isChecked) {
                    val action = direction.actionQuartaperguntaToQuintapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q4C.isChecked) {
                    val action = direction.actionQuartaperguntaToQuintapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)

                }
            }

        }
        return view
    }

}
