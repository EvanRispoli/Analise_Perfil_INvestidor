package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta7Binding

class pergunta7 : Fragment() {

    private var _binding: FragmentPergunta7Binding? = null
    private val binding get() = _binding!!
    val args : pergunta7Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta7Binding.inflate(inflater, container, false)
        binding.back7?.setOnClickListener{
            findNavController().popBackStack()
        }
        val view = binding.root
        binding.btn7.setOnClickListener {
            val direction = pergunta7Directions

            if(binding.R7A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q7A.isChecked) {
                    val action = direction.actionSetimaperguntaToOitavapergunta(args.pontos + 0)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q7B.isChecked) {
                    val action = direction.actionSetimaperguntaToOitavapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q7C.isChecked) {
                    val action = direction.actionSetimaperguntaToOitavapergunta(args.pontos + 3)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q7D.isChecked) {
                    val action = direction.actionSetimaperguntaToOitavapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)
                }
            }
        }
        return view
    }


}
