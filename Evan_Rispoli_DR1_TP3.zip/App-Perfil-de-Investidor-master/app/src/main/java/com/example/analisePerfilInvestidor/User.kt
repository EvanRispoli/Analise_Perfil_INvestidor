package com.example.analisePerfilInvestidor

import java.io.Serializable

class User(
    var nome:String = "",
    var pontos: Int = 0
):Serializable