package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta5Binding

class pergunta5 : Fragment() {


    private var _binding: FragmentPergunta5Binding? = null
    private val binding get() = _binding!!
    val args : pergunta5Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta5Binding.inflate(inflater, container, false)
        binding.back5?.setOnClickListener{
            findNavController().popBackStack()
        }
        val view = binding.root

        binding.btn5.setOnClickListener {
            val direction = pergunta5Directions
            if(binding.R5A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q5A.isChecked) {
                    val action = direction.actionQuintaperguntaToSextapergunta(args.pontos + 0)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q5B.isChecked) {
                    val action = direction.actionQuintaperguntaToSextapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q5C.isChecked) {
                    val action = direction.actionQuintaperguntaToSextapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)

                }
            }
        }
        return view
    }
}