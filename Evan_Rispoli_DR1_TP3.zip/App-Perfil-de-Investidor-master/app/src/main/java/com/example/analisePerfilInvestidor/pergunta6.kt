package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta6Binding

class pergunta6 : Fragment() {

    private var _binding: FragmentPergunta6Binding? = null
    private val binding get() = _binding!!
    val args: pergunta6Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta6Binding.inflate(inflater, container, false)
        binding.back6?.setOnClickListener {
            findNavController().popBackStack()
        }
        val view = binding.root

        binding.btn6.setOnClickListener {
            val direction = pergunta6Directions

            if (binding.R6A.checkedRadioButtonId == -1) {
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            } else {
                if (binding.Q6A.isChecked) {
                    val action = direction.actionSextaperguntaToSetimapergunta(args.pontos + 0)
                    Navigation.findNavController(view).navigate(action)
                } else if (binding.Q6B.isChecked) {
                    val action = direction.actionSextaperguntaToSetimapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                } else if (binding.Q6C.isChecked) {
                    val action = direction.actionSextaperguntaToSetimapergunta(args.pontos + 3)
                    Navigation.findNavController(view).navigate(action)
                } else if (binding.Q6D.isChecked) {
                    val action = direction.actionSextaperguntaToSetimapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)
                }
            }
        }
        return view
    }

}
