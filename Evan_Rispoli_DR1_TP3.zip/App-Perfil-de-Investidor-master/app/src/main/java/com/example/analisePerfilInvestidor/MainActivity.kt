package com.example.analisePerfilInvestidor

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.analisePerfilInvestidor.databinding.ActivityMainBinding

lateinit var binding: ActivityMainBinding
var user = User()

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.iniciar.setOnClickListener {
            if (binding.tvinput.text.isEmpty()) {
                Toast.makeText(this, "Preencha o campo nome", Toast.LENGTH_SHORT).show()
            } else {

                user.nome = binding.tvinput.text.toString()
                var intent = Intent(this, Perguntas::class.java)
                intent.putExtra("nome", user)
                startActivity(intent)


            }
        }
    }
}