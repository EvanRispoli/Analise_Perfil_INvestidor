package com.example.analisePerfilInvestidor

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.analisePerfilInvestidor.databinding.ActivityResultadoBinding


lateinit var binding2: ActivityResultadoBinding

class Resultado : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding2 = ActivityResultadoBinding.inflate(layoutInflater)
        val view = binding2.root
        setContentView(view)

        var pontos = intent.getSerializableExtra("pontos")
        var pontuacao:Int = pontos as Int


        if (pontos <= 12){
            binding2.Resultado.text = "Conservador"
        }
        else if (pontos in 13..29){
            binding2.Resultado.text = "Moderado"
        }
        else{
            binding2.Resultado.text = "Arrojado"
        }

        binding2.btnReiniciar.setOnClickListener {
                user.nome = binding.tvinput.text.toString()
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)



        }








    }

}