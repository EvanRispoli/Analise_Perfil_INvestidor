package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta2Binding

class pergunta2 : Fragment() {


    private var _binding: FragmentPergunta2Binding? = null
    private val binding get() = _binding!!
    val args : pergunta2Args by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta2Binding.inflate(inflater, container, false)

        val view = binding.root

        binding.back?.setOnClickListener{
            findNavController().popBackStack()
        }
        binding.btn2.setOnClickListener {
            val direction = pergunta2Directions

            if(binding.R2A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q2A.isChecked) {
                    val action = direction.actionSegundaperguntaToTerceirapergunta(args.pontos)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q2B.isChecked) {
                    val action = direction.actionSegundaperguntaToTerceirapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q2C.isChecked) {
                    val action = direction.actionSegundaperguntaToTerceirapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q2D.isChecked) {
                    val action = direction.actionSegundaperguntaToTerceirapergunta(args.pontos + 5)
                    Navigation.findNavController(view).navigate(action)

                }
            }

        }
        return view
    }
}

