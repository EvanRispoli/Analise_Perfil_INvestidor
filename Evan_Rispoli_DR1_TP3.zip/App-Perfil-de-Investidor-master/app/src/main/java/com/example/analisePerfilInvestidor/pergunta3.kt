package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta3Binding

class pergunta3 : Fragment() {

    private var _binding: FragmentPergunta3Binding? = null
    private val binding get() = _binding!!
    val args : pergunta3Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta3Binding.inflate(inflater, container, false)
        binding.back3?.setOnClickListener{
            findNavController().popBackStack()
        }
        val view = binding.root

        binding.btn3.setOnClickListener {
            val direction = pergunta3Directions
            if(binding.R3A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q3A.isChecked) {
                    val action = direction.actionTerceiraperguntaToQuartapergunta(args.pontos)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q3B.isChecked) {
                    val action = direction.actionTerceiraperguntaToQuartapergunta(args.pontos + 1)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q3C.isChecked) {
                    val action = direction.actionTerceiraperguntaToQuartapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q3D.isChecked) {
                    val action = direction.actionTerceiraperguntaToQuartapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)

                }
            }

        }
        return view
    }
}
