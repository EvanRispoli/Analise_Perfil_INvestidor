package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta1Binding


class pergunta1 : Fragment() {

    private var _binding: FragmentPergunta1Binding? = null
    private val binding get() = _binding!!

    val args: pergunta2Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta1Binding.inflate(inflater, container, false)
        val view = binding.root
        var pontos: Int = 0
        val data = arguments

        binding.btn1.setOnClickListener {
            val direction = pergunta1Directions
            val AltA = 0
            val AltB = 2
            val AltC = 3
            val AltD = 4

            if (binding.R1A.checkedRadioButtonId == -1) {
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            } else {
                if (binding.Q1A.isChecked) {
                    val action = direction.actionPrimeiraperguntaToSegundapergunta2(AltA)
                    findNavController(view).navigate(action)
                } else if (binding.Q1B.isChecked) {
                    val action = direction.actionPrimeiraperguntaToSegundapergunta2(AltB)
                    findNavController(view).navigate(action)
                } else if (binding.Q1C.isChecked) {
                    val action = direction.actionPrimeiraperguntaToSegundapergunta2(AltC)
                    findNavController(view).navigate(action)

                } else if (binding.Q1D.isChecked) {
                    val action = direction.actionPrimeiraperguntaToSegundapergunta2(AltD)
                    findNavController(view).navigate(action)

                }
            }

        }
        return view

    }
}





