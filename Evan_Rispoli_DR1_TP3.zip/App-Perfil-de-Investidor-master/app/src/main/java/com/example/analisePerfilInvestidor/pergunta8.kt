package com.example.analisePerfilInvestidor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.analisePerfilInvestidor.databinding.FragmentPergunta8Binding


class pergunta8 : Fragment() {


    private var _binding: FragmentPergunta8Binding? = null
    private val binding get() = _binding!!
    val args : pergunta8Args by navArgs()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPergunta8Binding.inflate(inflater, container, false)
        binding.back8?.setOnClickListener{
            findNavController().popBackStack()
        }
        val view = binding.root

        binding.btn8.setOnClickListener {
            val direction = pergunta8Directions

            if(binding.R8A.checkedRadioButtonId ==-1){
                Toast.makeText(context, "Selecione uma alternativa", Toast.LENGTH_LONG).show()
            }else {
                if (binding.Q8A.isChecked) {
                    val action = direction.actionOitavaperguntaToNonapergunta(args.pontos + 0)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q8B.isChecked) {
                    val action = direction.actionOitavaperguntaToNonapergunta(args.pontos + 1)
                    Navigation.findNavController(view).navigate(action)

                }
                else if (binding.Q8C.isChecked) {
                    val action = direction.actionOitavaperguntaToNonapergunta(args.pontos + 2)
                    Navigation.findNavController(view).navigate(action)
                }
                else if (binding.Q8D.isChecked) {
                    val action = direction.actionOitavaperguntaToNonapergunta(args.pontos + 4)
                    Navigation.findNavController(view).navigate(action)
                }
            }

        }
        return view
    }



}
