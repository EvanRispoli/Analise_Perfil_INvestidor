# App-Perfil-de-Investidor
Primeiro aplicativo desenvolvido.<br>
App Perfil Investidor em Kotlin com 9 perguntas
<br><br>
![app12](https://user-images.githubusercontent.com/63150786/172281492-12ffdbcb-c1b4-4f58-adf0-098bb7601b39.PNG)
<br>
![app13](https://user-images.githubusercontent.com/63150786/172281493-79e0fa75-8db7-479a-9c44-82df2be8da3b.PNG)
<br>
![app16](https://user-images.githubusercontent.com/63150786/172282029-4572c68c-97bb-4dbf-88fa-63b5fd27fe1a.PNG)




